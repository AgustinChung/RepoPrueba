package modelo;

public class UbicacionNeutral extends Ubicacion{

	private Heroe heroe;
	private Recompensa recompensa;
	
	
	protected UbicacionNeutral(String nombre, Heroe heroe) {
		super(nombre, heroe);
	}

	
	//setea al maximo los puntos de vida del heroe
	public void descansar(Heroe heroe) {
		int puntosVidaMaxima = heroe.getPuntosVidaMaxima();
		heroe.setPuntosVida(puntosVidaMaxima);
	}
	

	//agarra los datos de la recompensa y setea nuevos valores en el ataque y defensa del heroe.
	//VER SI RECIBE UNA SOLA RECOMPENSA O UNA LISTA DE RECOMPENSAS.
	@Override
	public void reclamarRecompensa() {
		Recompensa recompensa = (Recompensa) heroe.getRecompensas();
		int ataque = this.heroe.getNivelAtaque();
		int defensa = this.heroe.getNivelDefensa();
				
		int aumentoAtaque = (int) this.recompensa.getPorcentajeAumentoAtaque();
		int aumentoDefensa = (int) this.recompensa.getPorcentajeAumentoDefensa();
		
		this.heroe.setNivelAtaque(ataque + (ataque*aumentoAtaque));
		this.heroe.setNivelDefensa(defensa + (defensa*aumentoDefensa));

	}
}
